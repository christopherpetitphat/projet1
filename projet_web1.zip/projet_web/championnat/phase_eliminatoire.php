<!DOCTYPE html>
        <head>
            <title>COUPE INFO 3</title>
            <meta charset="utf-8">
            <link href="styles.css" rel="Stylesheet"  /> 
            <script src="https://kit.fontawesome.com/a076d05399.js"></script>
            <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
        </head>
    <body>
                    <nav>
                        <input type="checkbox" id="check">
                        <label for="check" class="checkbtn">
                        </label>
                        <label class="logo">CHAMPIONNAT</label>
                        <ul>
                        <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
                            <li><p> <i class="fa fa-sort"><a href="classement.php">Classement</a></i></p></li>
                        </ul>
                    </nav>
        <section>    
           <br><br><br>

                <!-- <button type='submit' name='previous'> <a href='phase_groupe.php'>PRECEDENT</a> </button> -->
                <center><a href="phase_groupe.php" ><button type='submit' name='previous'>PRECEDENT</button></center></a><br/>

                <!-- <button type='submit' name='classement'> <a href='classement.php'> Voir le classement </a> </button> -->
                <center><a href="classement.php" ><button type='submit' name='classement'>Voir le classement</button></center></a><br/><br/>

                <?php
                    include "connexion_BD.php";


                                    $pointA = [];
                                    $difA = [];
                                    $promuA=[];
                                    $flagA=[];
                                    
                                    
                                        $req = "SELECT * from classement_groupea ORDER BY points DESC";
                                        $result = $conn->query($req);
                                        $row = $result->fetchAll();
                                        for($i = 0; $i < count($row); $i++){
                                            $pointsA[] = $row[$i]['points'];
                                            $difA[] = $row[$i]['dif'];
                                            $promuA[]=$row[$i]['nom_equipe'];
                                            $flagA[]=$row[$i]['drapeau'];

                                        }
                            
                                        $pointB = [];
                                        $difB = [];
                                        $promuB=[];
                                        $flagB=[];
                                    
                                        $req1 = "SELECT * from classement_groupeb ORDER BY points DESC";
                                        $result = $conn->query($req1);
                                        $row = $result->fetchAll();
                                        for($i = 0; $i < count($row); $i++){
                                            $pointB[] = $row[$i]['points'];
                                            $difB[] = $row[$i]['dif'];
                                            $promuB[]=$row[$i]['nom_equipe'];
                                            $flagB[]=$row[$i]['drapeau'];
                                        }

                                        $score1=[];
                                    $score2=[];
                                    $match=[];
                                        $req2 = "SELECT * from match_joue ORDER BY num_match ASC";
                                        $result = $conn->query($req2);
                                        $row = $result->fetchAll();
                                        for($i = 0; $i < count($row); $i++){
                                            $score1[] = $row[$i]['score1'];
                                            $score2[] = $row[$i]['score2'];
                                            $match[]=$row[$i]['num_match'];
                                        }

                                        //   for($i=0; $i<4;$i++){
                                        //       if($pointA[$i]==$pointA[$i+1]){
                                        //         $req = "SELECT * from classement_groupea ORDER BY points DESC";
                                        //         $result = $conn->query($req);
                                        //         $row = $result->fetchAll();
                                        //         for($i = 0; $i < count($row); $i++){
                                        //             $pointsA[] = $row[$i]['points'];
                                        //             $difA[] = $row[$i]['dif'];
                                        //             $promuA[]=$row[$i]['nom_equipe'];
                                        //         }
                                                
                                                


                                        //       }                                        

                    session_start();
                                    
               ?>

            <article>
                    <div class="mes_articles">
                            <br/><h1> PHASE ELIMINATOIRE </h1>
                            <form method='POST'>
                                <label> <img src='<?php echo $flagA[0]?>'><?php echo $promuA[0] ;       ?> 
                                <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[12]]?>' class="form-contr"> VS
                                <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[12]]?>' class="form-contr"> 
                                <label> <?php echo $promuB[1] ;?><img src='<?php echo $flagB[1]?>'></br></br>
                                <button type='submit' <?php if(isset($match[12])){echo'disabled';}?> name='valider1'class="form-contro submit"> jouer match</button></br></br>
                            </form>
                <?php
                        if(isset($_POST['valider1']))
                        {
                            do {
                                $scr1=rand(0,5);
                                $scr2=rand(0,5);
                            }while($scr1==$scr2);

                        $insert = "INSERT INTO match_joue VALUES (null,12,$scr1,$scr2,'eliminatoire')";
                                    $conn->exec($insert);
                        header('location:phase_eliminatoire.php');
                            if($scr1>$scr2){
                                $_SESSION['final1']=$promuA[0];
                                $_SESSION['ptFinal1']=$promuB[1];

                            }
                            elseif($scr1<$scr2){
                                $_SESSION['final1']=$promuB[1];
                                $_SESSION['ptFinal1']=$promuA[0];

                            }
                            else{

                            }
                        }


                 ?>
<!-- ------------------------------------------------------------------------------------------------------------------------------ -->

                <form method='POST'>
                    <label> <img src='<?php echo $flagB[0]?>'><?php echo $promuB[0] ;       ?> 
                    <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[13]]?>' class="form-contr"> VS
                    <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score2[$match[13]]?>' class="form-contr">
                    <label> <?php echo $promuA[1] ;?><img src='<?php echo $flagA[1]?>'></br></br>
                    <button type='submit'  <?php if(!isset($match[12]) || isset($match[13])){echo'disabled';}?> name='valider2'class="form-contro submit"> jouer match</button></br></br>
                </form>
                <?php
                    if(isset($_POST['valider2']))
                    {
                        do {
                            $scr1=rand(0,5);
                            $scr2=rand(0,5);
                        }while($scr1==$scr2);
                            


                    $insert = "INSERT INTO match_joue VALUES (null,13,$scr1,$scr2,'eliminatoire')";
                                $conn->exec($insert);
                                header('location:phase_eliminatoire.php');
                        if($scr1>$scr2){
                            $_SESSION['final2']=$promuB[0];
                            $_SESSION['ptFinal2']=$promuA[1];

                        }
                        elseif($scr1<$scr2){
                            $_SESSION['final2']=$promuA[1];
                            $_SESSION['ptFinal2']=$promuB[0];

                        }
                        else{
                            
                        }
                    }                    

                ?>
<!-- ------------------------------------------------------------------------------------------------------------------------------ -->

                <br/>
                <?php
                    if(isset($match[13]))
                 {?>
                  <center><a href="phase_finale.php" >SUIVANT</a></center><br/><br/>
                                    
                 <?php } ?>


   </body>
<html>
