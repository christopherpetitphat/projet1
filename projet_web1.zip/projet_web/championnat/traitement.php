<!DOCTYPE html>
<head>
    <title>COUPE INFO 3</title>
    <meta charset="utf-8">
    <link href="style.css" rel="Stylesheet"  /> 
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
</head>
<body>
   <nav>
       <input type="checkbox" id="check">
       <label for="check" class="checkbtn">
       </label>
       <label class="logo">CHAMPIONNAT</label>
       <ul>
        <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
        <li><p> <i class="fa fa-sort"><a href="classement.php">Classement</a></i></p></li>
      </ul>
   </nav>
   <section>    
           <br><br><br>
          <!-- <button type='submit' name='classement' class="form-contro submit"> <a href='classement.php'> Voir le classement </a> </button> -->
          <center><a href="classement.php" ><button type='submit' name='classement'>Voir le classement</button></center></a><br/><br/>

          
          <?php
                // connection a la base de donnée
                include 'connexion_BD.php';
                session_start();

                // Tirage aléatoire
                do{

                    $a=array_rand($_SESSION ['lot1']);
                    $b=array_rand($_SESSION ['lot1']);
                    $c=array_rand($_SESSION ['lot2']);
                    $d=array_rand($_SESSION ['lot2']);
                    $e=array_rand($_SESSION ['lot3']);
                    $f=array_rand($_SESSION ['lot3']);
                    $g=array_rand($_SESSION ['lot4']);
                    $h=array_rand($_SESSION ['lot4']);

                        }while($a==$b || $d==$c || $e==$f || $g==$h  );


                            $groupeA[]=$_SESSION ['lot1'][$a];
                            $groupeA[]=$_SESSION ['lot2'][$c];
                            $groupeA[]=$_SESSION ['lot3'][$e];
                            $groupeA[]=$_SESSION ['lot4'][$g];

                            $groupeB[]=$_SESSION ['lot1'][$b];
                            $groupeB[]=$_SESSION ['lot2'][$d];
                            $groupeB[]=$_SESSION ['lot3'][$f];
                            $groupeB[]=$_SESSION ['lot4'][$h];


                            // Enregistrement des groupes dans la base de données

                            $supp = "DELETE FROM groupea";
                            $conn->exec($supp);
                            $supp2 = "DELETE FROM groupeb";
                            $conn->exec($supp2);
                            $supp3 = "DELETE FROM classement_groupea";
                            $conn->exec($supp3);
                            $supp4 = "DELETE FROM classement_groupeb";
                            $conn->exec($supp4);
                            $supp5 = "DELETE FROM match_joue";
                            $conn->exec($supp5);
                            $supp5 = "DELETE FROM phase_finale";
                            $conn->exec($supp5);


                            for ($i = 0; $i < 4; $i++){
                            $insertA = "INSERT INTO groupea VALUES (null, '$groupeA[$i]','image/$groupeA[$i].png')";
                            $conn->exec($insertA);
                                    }
                            for ($i = 0; $i < 4; $i++){
                            $insertB = "INSERT INTO groupeb VALUES (null, '$groupeB[$i]','image/$groupeB[$i].png')";
                                $conn->exec($insertB);
                                    }


                        // Ajout des noms d'équipe dans les table de classement
                                    $gA = [];
                                    $flagA = [];
                                    $req = "SELECT * from groupea";
                                    $result = $conn->query($req);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                        $gA[] = $row[$i]['nom_equipe'];
                                        $flagA[] = $row[$i]['drapeau'];
                                    }
                        
                                    $gB = [];
                                    $flagB = [];
                                    $req1 = "SELECT * from groupeb";
                                    $result = $conn->query($req1);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                        $gB[] = $row[$i]['nom_equipe'];
                                        $flagB[] = $row[$i]['drapeau'];
                                    }

                                    
                        
                        
                        
                                $insert = "INSERT INTO classement_groupea VALUES (null,'$gA[0]','$flagA[0]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insert);
                        
                                $insert1 = "INSERT INTO classement_groupea VALUES (null,'$gA[1]','$flagA[1]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insert1);
                        
                                $insert2 = "INSERT INTO classement_groupea VALUES (null,'$gA[2]','$flagA[2]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insert2);
                        
                                $insert3 = "INSERT INTO classement_groupea VALUES (null,'$gA[3]','$flagA[3]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insert3);
                        
                        
                        
                                $insertB = "INSERT INTO classement_groupeb VALUES (null,'$gB[0]','$flagB[0]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insertB);
                        
                                $insertB1 = "INSERT INTO classement_groupeb VALUES (null,'$gB[1]','$flagB[1]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insertB1);
                        
                                $insertB2 = "INSERT INTO classement_groupeb VALUES (null,'$gB[2]','$flagB[2]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insertB2);
                        
                                $insertB3 = "INSERT INTO classement_groupeb VALUES (null,'$gB[3]','$flagB[3]', 0, 0, 0, 0, 0, 0, 0, 0)";
                                $conn->exec($insertB3);


                                header('location:index.php#tableau');
                    


            ?>
     
            </br> </br> </br> 
        </section>
    </body>
</html>