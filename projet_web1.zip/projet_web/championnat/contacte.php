<!DOCTYPE html>
<html>          
    <HEAD>
        <title>COUPE INFO 3</title>
            <meta charset="utf-8">
            <link href="stylef.css" rel="Stylesheet"  /> 
            <script src="https://kit.fontawesome.com/a076d05399.js"></script>
            <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
             
                    <script language="Javascript">
                        function f() {
                            var tab = document.getElementsByTagName ("input");
                            var result;
                            for (i = 0; i < tab.length; i++) {
                            result = result + " " + (tab[i].value);
                            }
                            document.contacte.result.value = result;
                        }
                    </script>
    </HEAD>
    <BODY >
        <nav>
            <input type="checkbox" id="check">
            <label for="check" class="checkbtn">
            </label>
            <label class="logo">Contacter-Nous</label>
            <ul>
                <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
            </ul>
        </nav>
    <section> 
         <?php
                  include 'connexion_BD.php'

        ?>  
     <article>
       <div class="mes_articles"><br>
        <form name="contacte">
            <label type="tel" name="identifiant" >Telephone * :</label>
            <input type="text" name="1" class="form-contro" value=" " required><br/><br/><br/>
            <label type="text" name="text">Adresse * :</label>
            <input type="adresse" name=2 class="form-contro" value=" "required><br/><br/><br/>
            <label type="texte" name="courriel">courriel * :</label>
            <input type="email" name="3" class="form-contro" value=" "required><br/><br/><br/>

                <input type="button" value="envoy!" name="click" onClick="f();"><br/>
                <textarea rows=4 cols=40 name="result"></textarea><br/><br/>
                    <button type="reset" class="form-contro submit" value="restaurer">annuler</button>
                    <button type="submit" class="form-contro submit" value="valider">valider</button> <br/><br>
        </form>
    </article>
       <br/> <center><a href="Manuel.php" ><button type="button">BACK</button></a></center><br/><br/>
    </BODY>
    </HTML>