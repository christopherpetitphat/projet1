<!DOCTYPE html>
        <head>
            <title>COUPE INFO 3</title>
            <meta charset="utf-8">
            <link href="styles.css" rel="Stylesheet"  /> 
            <script src="https://kit.fontawesome.com/a076d05399.js"></script>
            <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
        </head>
    <body>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                </label>
                <label class="logo">CHAMPIONNAT</label>
                <ul>
                    <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
                    <li><p> <i class="fa fa-sort"><a href="classement.php">Classement</a></i></p></li>
                </ul>
            </nav>
         <section>    
                        <br><br><br>
                <!-- <button type='submit' name='previous'> <a href='phase_groupe.php'>PRECEDENT</a> </button> -->
                <center><a href="phase_groupe.php" ><button type='submit' name='previous'>PRECEDENT</button></center></a><br/>
                <!-- 
                <button type='submit' name='classement'> <a href='classement.php'> Voir le classement </a> </button> -->
                <center><a href="classement.php" ><button type='submit' name='classement'>Voir le classement</button></center></a><br/><br/>

                <?php
                    session_start();
                    include "connexion_BD.php";
                    $score1=[];
                                    $score2=[];
                                    $match=[];
                                        $req2 = "SELECT * from match_joue ORDER BY num_match ASC";
                                        $result = $conn->query($req2);
                                        $row = $result->fetchAll();
                                        for($i = 0; $i < count($row); $i++){
                                            $score1[] = $row[$i]['score1'];
                                            $score2[] = $row[$i]['score2'];
                                            $match[]=$row[$i]['num_match'];
                                        }

                ?>
                <article>
                        <div class="mes_articles">
                            <br/><h1> PETITE FINALE </h1>
                        <form method='POST'>
                            <label> <img src='image/<?php echo $_SESSION['ptFinal1']?>.png'><?php echo $_SESSION['ptFinal1'] ;       ?> 
                            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[14]]?>' class="form-contr"> VS
                            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[14]]?>' class="form-contr">  
                            <label> <?php echo $_SESSION['ptFinal2'] ;?><img src='image/<?php echo $_SESSION['ptFinal2']?>.png'></br></br>
                            <button type='submit' <?php if(isset($match[14])){echo'disabled';}?> name='valider1'class="form-contro submit"> jouer match</button></br></br>
                        </form>
                        <?php
                            if(isset($_POST['valider1']))
                            {
                            do {
                                $scr1=rand(0,5);
                                $scr2=rand(0,5);
                            }while($scr1==$scr2);

                            $insert = "INSERT INTO match_joue VALUES (null,14,$scr1,$scr2,'petite finale')";
                                        $conn->exec($insert);
                            header('location:phase_finale.php');
                            if($scr1>$scr2){
                                $troisieme=$_SESSION['ptFinal1'];
                                

                            $insert = "INSERT INTO phase_finale VALUES (null,'$troisieme','troisieme')";
                                $conn->exec($insert);
                                
                            }
                            elseif($scr1<$scr2){
                                $troisieme=$_SESSION['ptFinal2'];

                                $insert = "INSERT INTO phase_finale VALUES (null,'$troisieme','troisieme')";
                                        $conn->exec($insert);

                            }
                            else{

                            }

                            
                            }

                        ?>
               
                    </div>
                </article>
<!-- ------------------------------------------------------------------------------------------------------------------------------ -->
                <article>
                        <div class="mes_articles">
                            <br/><h1>GRANDE FINALE<h1>
                            <form method='POST'>
                                <label> <img src='image/<?php echo $_SESSION['final1']?>.png'><?php echo $_SESSION['final1'] ;       ?> 
                                <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[15]]?>' class="form-contr"> VS
                                <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[15]]?>' class="form-contr"> 
                                <label> <?php echo $_SESSION['final2'] ;?><img src='image/<?php echo $_SESSION['final2']?>.png'></br></br>
                                <button type='submit'<?php if(!isset($match[14]) || isset($match[15])){echo'disabled';}?> name='valider2'class="form-contro submit"> jouer match</button></br></br>
                            </form>
                            <?php
                                if(isset($_POST['valider2']))
                                {
                                do {
                                    $scr1=rand(0,5);
                                    $scr2=rand(0,5);
                                }while($scr1==$scr2);

                                $insert = "INSERT INTO match_joue VALUES (null,15,$scr1,$scr2,'finale')";
                                            $conn->exec($insert);
                                header('location:phase_finale.php');
                                if($scr1>$scr2){
                                $premier=$_SESSION['final1'];
                                $deuxieme=$_SESSION['final2'];

                                $insert = "INSERT INTO phase_finale VALUES (null,'$premier','premier')";
                                    $conn->exec($insert);

                                    $insert1 = "INSERT INTO phase_finale VALUES (null,'$deuxieme','deuxieme')";
                                    $conn->exec($insert1);
                                    
                                }
                                elseif($scr1<$scr2){
                                $premier=$_SESSION['final2'];
                                $deuxieme=$_SESSION['final1'];

                                $insert = "INSERT INTO phase_finale VALUES (null,'$premier','premier')";
                                    $conn->exec($insert);
                                    
                                    $insert1 = "INSERT INTO phase_finale VALUES (null,'$deuxieme','deuxieme')";
                                    $conn->exec($insert1);


                                }
                                else{

                                }
                                }

                            ?>

                            <?php
                              if(isset($match[15]))
                           {?>
                                    <center><a href="finale.php" >SUIVANT</a></center><br/><br/>
                                    
                            <?php } ?>
                    </div>
                </article>    
                <!-- ------------------------------------------------------------------------------------------------------------------------------ -->

    </body>
</html>