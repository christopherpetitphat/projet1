<!DOCTYPE html>
        <head>
            <title>COUPE INFO 3</title>
            <meta charset="utf-8">
            <link href="styleM.css" rel="Stylesheet"  /> 
            <script src="https://kit.fontawesome.com/a076d05399.js"></script>
            <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
        </head>
    <body>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                </label>
                <label class="logo">Notice & Manuel d'utilisation</label>
                <ul>
                    <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
                   
                </ul>
            </nav>
        <section> 
     
                <?php
                  include 'connexion_BD.php'

                ?>
      <br><br>
        <article>
            <div class="mes_articles">                     
                        <br/><h1 class="ecrit">A propos de nous</h1>
          <p>Ce site a été crée par un groupe d'etudiants dans le but de permet aux utilisateur de faire des matchs de façons alternative
              c'est-a-dire l'un apres l'autre </p><br>
              <p>on peut constater dans la page d'acceuil un petit tableau qui comporte a peu pres quatre(4) lots et a chaque lots est 
                  composés de deux (2) equipes</p>
                
               <p>la composition des quatres lots de la zone d equipes:
                          <p>Lots 1:</p>
                          <p>Lots 2:</p>
                          <p>Lots 3:</p>
                          <p>Lots 4:</p>
                </p>         
                <p>c'est a travers ces equipes qu'on va Effectuer les matchs</p><br>
                <p>Pour Effectuer les matchs il faut cliquer sur le bouton <h4>"Effectuer tirage"</h4>, apres avoir cliquer le tirage va se faire automatiquement
                    ensuite presser le bouton <h4>"Suivant"</h4> qui va vous ammener vers la page oú se trouve les differents équipes. </p>
                    <p>Pour realiser un match il suffit de cliquer sur le bouton <h4>"Jouer Match"</h4>, ne vous inqiuetez pas pour le score, il 
                        se fait de maniere automatique.
                    </p>
                    <p>Apres avoir Effectuer tous les matchs successivement, un bouton <h4>"Suivant"</h4> va apparement paraitre par magie, et n'hésitez pas
                 a presser dessus, cela va vous permet de voir et de vous orienter vers la phase eliminatoire. Et ceci presentera dans l'autre page qui est la page petite-finale
                et grande-finale </p><br>
                 <p><h3>je vous remercie chaleureusement d avoir pris un peu de temps de lire les infos, et de visitez notre site qui est la pour vour divertir.
                     Pour plus d'info faut pas hésiter a nous contacter nous somme lá a votre guise.</h3></p><br>
            </div>
        </article>
        <br/> <center><a href="contacte.php" ><button type="button">CONTACT</button></a></center><br/><br/>
<!-- ------------------------------------------------------------------------------------------------------------------------------ -->


     </body>
     <br><br><br>
     <footer>
        <div id="copy"> CHAMPIONNAT </div>
     </footer>
<html>
