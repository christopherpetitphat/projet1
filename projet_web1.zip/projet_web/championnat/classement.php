<!DOCTYPE html>
<head>
    <title>COUPE INFO 3</title>
    <meta charset="utf-8">
    <link href="style.css" rel="Stylesheet"  /> 
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
</head>
<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
        </label>
        <label class="logo">CHAMPIONNAT</label>
        <ul>
            <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
            <li><p> <i class="fa fa-sort"><a href="classement.php">Classement</a></i></p></li>
        </ul>
    </nav>
        <section>    
                <center><h1>
                        <span>c</span>
                        <span>l</span>
                        <span>a</span>
                        <span>s</span>
                        <span>s</span>
                        <span>e</span>
                        <span>m</span>
                        <span>e</span>
                        <span>n</span>
                        <span>t</span>
                    </h1></center>
                <?php
                session_start();
                include "connexion_BD.php"




                ?>
                <article>

                        <div class="mes_article">
                            <div class="searchs">
                    
                                    <table class="tableau-style"> 
                                        <tr><th>Classement GROUPE A<th><tr>
                                        <th></th>
                                        <th>MJ</th>
                                        <th>MG</th>
                                        <th>MN</th>
                                        <th>MP</th>
                                        <th>BP</th>
                                        <th>BC</th>
                                        <th>DIF</th>
                                        <th>Point</th>
                                        
                                        <?php
                                                    $req = "SELECT * from classement_groupea ORDER BY points DESC";
                                                    $result = $conn->query($req);
                                                    $row = $result->fetchAll();
                                                    for($i = 0; $i < count($row); $i++){
                                                ?>
                                                    <tr>
                                                        <td><img src='<?php echo $row[$i][2] ?>'><?php echo $row[$i][1] ?></td>
                                                        <td><?php echo $row[$i][3] ?></td>
                                                        <td><?php echo $row[$i][4] ?></td>
                                                        <td><?php echo $row[$i][5] ?></td>
                                                        <td><?php echo $row[$i][6] ?></td>
                                                        <td><?php echo $row[$i][7] ?></td>
                                                        <td><?php echo $row[$i][8] ?></td>
                                                        <td><?php echo $row[$i][9] ?></td>
                                                        <td><?php echo $row[$i][10] ?></td>
                                                        
                                                    </tr>

                                                <?php } ?>
                                            
                                    </table>

                                                    </br>

                                
                                    <table class="tableau-style"> 
                                        <tr><th>Classement GROUPE B<th><tr>
                                        <th></th>
                                        <th>MJ</th>
                                        <th>MG</th>
                                        <th>MN</th>
                                        <th>MP</th>
                                        <th>BP</th>
                                        <th>BC</th>
                                        <th>DIF</th>
                                        <th>Point</th>
                                        
                                        <?php
                                                    $req = "SELECT * from classement_groupeb ORDER BY points DESC";
                                                    $result = $conn->query($req);
                                                    $row = $result->fetchAll();
                                                    for($i = 0; $i < count($row); $i++){
                                                ?>
                                                    <tr>
                                                    
                                                        <td><img src='<?php echo $row[$i][2] ?>'><?php echo $row[$i][1] ?></td>
                                                        <td><?php echo $row[$i][3] ?></td>
                                                        <td><?php echo $row[$i][4] ?></td>
                                                        <td><?php echo $row[$i][5] ?></td>
                                                        <td><?php echo $row[$i][6] ?></td>
                                                        <td><?php echo $row[$i][7] ?></td>
                                                        <td><?php echo $row[$i][8] ?></td>
                                                        <td><?php echo $row[$i][9] ?></td>
                                                        <td><?php echo $row[$i][10] ?></td>
                                                        
                                                    </tr>

                                                <?php } ?>
                                            
                                    </table>
                                    </div>                  
                        </div>           
                    </div>
                </article>
                </br></br></br></br></br>

        </section>
    </body>
</html>