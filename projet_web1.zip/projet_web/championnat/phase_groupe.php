<!DOCTYPE html>
        <head>
            <title>COUPE INFO 3</title>
            <meta charset="utf-8">
            <link href="styles.css" rel="Stylesheet"  /> 
            <script src="https://kit.fontawesome.com/a076d05399.js"></script>
            <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
        </head>
        <body>
        <nav>
            <input type="checkbox" id="check">
            <label for="check" class="checkbtn">
            </label>
            <label class="logo">CHAMPIONNAT</label>
            <ul>
                <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
                <li><p> <i class="fa fa-sort"><a href="classement.php">Classement</a></i></p></li>
            </ul>
        </nav>
            <section>    
                            <br><br><br>
                    <!-- <button type='submit' name='previous' class="form-contro submit"> <a href='index.php'>PRECEDENT</a> </button> -->
                    <center><a href="index.php" ><button type='submit' name='previous'>PRECEDENT</button></center></a><br/><br/>

                    <?php
                include "connexion_BD.php";

                function jouerMatch($score1, $score2, $eq1,$eq2,$classement){
                    include "connexion_BD.php";
                    $class=$classement;

                    if($score1>$score2)
                        {
                    $equipe1= $eq1;
                    $mj1=1;
                    $dif1 = $score1 - $score2;
                    $bp1 = $score1;
                    $bc1 = $score2;
                    $mn1=0;
                    $mg1=1;
                    $mp1=0;
                    $pt1 =3;

                    $equipe2= $eq2;
                    $mj2=1;
                    $dif2 = $score2 - $score1;
                    $bp2 = $score2;
                    $bc2 = $score1;
                    $mn2=0;
                    $mg2=0;
                    $mp2=1;
                    $pt2 =0;
                        }
                        elseif($score1<$score2)
                        {
                            $equipe1= $eq1;
                            $mj1=1;
                            $dif1 = $score1 - $score2;
                            $bp1 = $score1;
                            $bc1 = $score2;
                            $mn1=0;
                            $mg1=0;
                            $mp1=1;
                            $pt1 =0;
                        
                            $equipe2= $eq2;
                            $mj2=1;
                            $dif2 = $score2 - $score1;
                            $bp2 = $score2;
                            $bc2 = $score1;
                            $mn2=0;
                            $mg2=1;
                            $mp2=0;
                            $pt2 =3;
                                }

                                else
                                {
                                    $equipe1= $eq1;
                                    $mj1=1;
                                    $dif1 = $score1 - $score2;
                                    $bp1 = $score1;
                                    $bc1 = $score2;
                                    $mn1=1;
                                    $mg1=0;
                                    $mp1=0;
                                    $pt1 =1;
                                
                                    $equipe2= $eq2;
                                    $mj2=1;
                                    $dif2 = $score2 - $score1;
                                    $bp2 = $score2;
                                    $bc2 = $score1;
                                    $mn2=1;
                                    $mg2=0;
                                    $mp2=0;
                                    $pt2 =1;
                                        }

                    $req1 = "UPDATE $class set MJ = MJ+$mj1,
                        MG = MG+$mg1,MN = MN+$mn1, MP = MP+$mp1, BP = BP+$bp1, 
                        BC = BC+$bc1, Dif = Dif+$dif1, 
                        POINTS = POINTS+$pt1 where nom_equipe = '$eq1'";
                    $conn->query($req1);

                    $req2 = "UPDATE $class set MJ = MJ+$mj2,
                        MG = MG+$mg2,MN = MN+$mn2, MP = MP+$mp2, BP = BP+$bp2, 
                        BC = BC+$bc2, Dif = Dif+$dif2, 
                        POINTS = POINTS+$pt2 where nom_equipe = '$eq2'";
                    $conn->query($req2);
                    
                }

                                $gA = [];
                                $flagA=[];
                                    $req = "SELECT * from classement_groupea";
                                    $result = $conn->query($req);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                        $gA[] = $row[$i]['nom_equipe'];
                                        $flagA[] = $row[$i]['drapeau'];
                                    }
                        
                                $gB = [];
                                $flagB=[];
                                    $req1 = "SELECT * from classement_groupeb";
                                    $result = $conn->query($req1);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                        $gB[] = $row[$i]['nom_equipe'];
                                        $flagB[] = $row[$i]['drapeau'];
                                    }

                                    $score1=[];
                                $score2=[];
                                $match=[];
                                    $req2 = "SELECT * from match_joue ORDER BY num_match ASC";
                                    $result = $conn->query($req2);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                        $score1[] = $row[$i]['score1'];
                                        $score2[] = $row[$i]['score2'];
                                        $match[]=$row[$i]['num_match'];
                                    }


    ?>


                                <!-- Match de la première Journée -->
        <article>
            <div class="mes_articles">
                <br/><h1> Journée 1 </h1>
                    <h2> GROUPE A </h2>

                    <?php
        
            
            if(isset($_POST['valider1']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,0,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gA[0],$gA[1],'classement_groupea');
                header('location:phase_groupe.php#match_1');
            }

        

            ?>

                        
                    <form id='match_1' method='POST'>
                        <label> <img src='<?php echo $flagA[0]?>'><?php echo $gA[0] ;  ?> 
                        <input  type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[0]]?>' class="form-contr"> VS
                        <input type="number"  disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[0]]?>' class="form-contr" > 
                        <label> <?php echo $gA[1] ;?><img src='<?php echo $flagA[1]?>'></br></br>
                        <button type='submit'  <?php if(isset($match[0])){echo'disabled';}?> name='valider1' class="form-contro submit"> jouer match</button></br></br>
                </form>
            
        

            <!-- ------------------------------------------------------------------------------------------------------------------------------ -->
            
            <?php
            if(isset($_POST['valider2']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
            else
                {
                    $scr1=rand(0,5);
                    $scr2=rand(0,5);
                    
                }

        $insert = "INSERT INTO match_joue VALUES (null,1,$scr1,$scr2,'groupe')";
                        $conn->exec($insert);
            jouerMatch($scr1,$scr2,$gA[2],$gA[3],'classement_groupea');
            header('location:phase_groupe.php#match_2');
            }

            ?>
            
            <form id='match_2' method='POST'>

            
            <label><img src='<?php echo $flagA[2]?>'> <?php echo $gA[2] ; ?> 
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[1]]?>' class="form-contr"> VS
            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[1]]?>' class="form-contr">
            <label> <?php echo $gA[3] ;?><img src='<?php echo $flagA[3]?>'></br></br>
            <button type='submit' <?php if(!isset($match[0]) || isset($match[1])){echo'disabled';}?> name='valider2'class="form-contro submit"> jouer match</button></br>

            </form>
            
            
        
            <!-- ------------------------------------------------------------------------------------------------------------------------------>
        </br>
            <h2> GROUPE B </h2>

            <?php
            if(isset($_POST['valider3']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,2,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gB[0],$gB[1],'classement_groupeb');
                header('location:phase_groupe.php#match_3');
                
                
            }

            ?>
            <form id='match_3' method='POST'>

            <label><img src='<?php echo $flagB[0]?>'> <?php echo $gB[0] ;  ?>
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[2]]?>' class="form-contr"> VS
            <input type="number"  disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[2]]?>' class="form-contr">
            <label> <?php echo     $gB[1] ;?><img src='<?php echo $flagB[1]?>'></br></br>
            <button type='submit' <?php if(!isset($match[1]) || isset($match[2])){echo'disabled';}?> name='valider3'class="form-contro submit"> jouer match</button></br></br>

            </form>

            
            <!-- ------------------------------------------------------------------------------------------------------------------------------>

            <?php
            ob_start();
                
            if(isset($_POST['valider4']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore2']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,3,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gB[2],$gB[3],'classement_groupeb');
                ob_end_flush(); 
                
                header('location:phase_groupe.php#match_4');
                
            
            }
            ?>
            
            <form id='match_4' method='POST'>

            <label><img src='<?php echo $flagB[2]?>'> <?php echo $gB[2] ;   ?> 
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[3]]?>' class="form-contr"> VS
            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[3]]?>'class="form-contr">
            <label> <?php echo   $gB[3] ;?><img src='<?php echo $flagB[3]?>'></br></br>
            <button type='submit' <?php if(!isset($match[2]) || isset($match[3])){echo'disabled';}?> name='valider4'class="form-contro submit"> jouer match</button></br></br>

            </form>

            
            </div>
        </div>
    </article>
            <!-- ------------------------------------------------------------------------------------------------------------------------------>



                                                    <!-- Match de la deuxième Journée -->
        <article>
            <div class="mes_articles">
                <br/>
                    <h1> Journée 2 </h1>
                    <h2> GROUPE A </h2>

                    <?php

                    ob_start();
            if(isset($_POST['valider5']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,4,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gA[0],$gA[2],'classement_groupea');
                ob_end_flush();
                header('location:phase_groupe.php#match_5');
                
            }

            ?>
                <form id='match_5' method='POST'>

            <label><img src='<?php echo $flagA[0]?>'> <?php echo $gA[0] ;  ?> 
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[4]]?>' class="form-contr"> VS
            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[4]]?>' class="form-contr">
            <label> <?php echo $gA[2] ;?><img src='<?php echo $flagA[2]?>'></br></br>
            <button type='submit' <?php if(!isset($match[3]) || isset($match[4])){echo'disabled';}?> name='valider5'class="form-contro submit"> jouer match</button></br></br>
            </form>
            
            <!-- ------------------------------------------------------------------------------------------------------------------------------ -->
            <form id='match_6' method='POST'>

            <label><img src='<?php echo $flagA[1]?>'> <?php echo $gA[1] ;       ?> 
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[5]]?>' class="form-contr"> VS
            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[5]]?>' class="form-contr">
            <label> <?php echo  $gA[3];?><img src='<?php echo $flagA[3]?>'></br></br>
            <button type='submit' <?php if(!isset($match[4]) || isset($match[5])){echo'disabled';}?> name='valider6'class="form-contro submit"> jouer match</button></br></br>

            </form>

            <?php
            if(isset($_POST['valider6']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,5,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gA[1],$gA[3],'classement_groupea');
                header('location:phase_groupe.php#match_6');
                
            }

            ?>
            <!-- ------------------------------------------------------------------------------------------------------------------------------>
            <form id='match_7' method='POST'>
            <h2> GROUPE B </h2>

            <label><img src='<?php echo $flagB[0]?>'> <?php echo $gB[0] ;       ?> 
            <input type="number" disabled  name='score1' min='0' max='12' value='<?php echo $score1[$match[6]]?>' class="form-contr"> VS
            <input type="number" disabled  name='score2' min='0' max='12' value='<?php echo $score2[$match[6]]?>' class="form-contr"> 
            <label> <?php echo     $gB[2] ;?><img src='<?php echo $flagB[2]?>'></br></br>
            <button type='submit' <?php if(!isset($match[5]) || isset($match[6])){echo'disabled';}?> name='valider7'class="form-contro submit"> jouer match</button></br></br>

            </form>

            <?php
            if(isset($_POST['valider7']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,6,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gB[0],$gB[2],'classement_groupeb');
                header('location:phase_groupe.php#match_7');
                
            }

            ?>
            <!-- ------------------------------------------------------------------------------------------------------------------------------>


            <form id='match_8'  method='POST'>

            <label><img src='<?php echo $flagB[1]?>'> <?php echo $gB[1] ;       ?>
            <input type="number" disabled   name='score1' min='0' max='12' value='<?php echo $score1[$match[7]]?>' class="form-contr"> VS
            <input type="number"  disabled   name='score2' min='0' max='12' value='<?php echo $score2[$match[7]]?>'class="form-contr"> 
            <label> <?php echo   $gB[3] ;?><img src='<?php echo $flagB[3]?>'></br></br>
            <button type='submit' <?php if(!isset($match[6]) || isset($match[7])){echo'disabled';}?> name='valider8'class="form-contro submit"> jouer match</button></br></br>

            </form>

            <?php
            if(isset($_POST['valider8']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,7,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gB[1],$gB[3],'classement_groupeb');
                header('location:phase_groupe.php#match_8');
                
            }

            ?>
                </div>
        </div>
    </article>
            <!-- ------------------------------------------------------------------------------------------------------------------------------>




                                                <!-- Match de la troisième Journée -->
            <article>
            <div class="mes_articles">
                <br/>
                                    <h1> Journée 3 </h1>
                            <h2> GROUPE A </h2>
            <form id='match_9' method='POST'>

            <label><img src='<?php echo $flagA[0]?>'> <?php echo $gA[0] ;       ?> 
            <input type="number" disabled    name='score1' min='0' max='12' value='<?php echo $score1[$match[8]]?>' class="form-contr"> VS
            <input type="number" disabled    name='score2' min='0' max='12' value='<?php echo $score2[$match[8]]?>' class="form-contr"> 
            <label> <?php echo $gA[3] ;?><img src='<?php echo $flagA[3]?>'></br></br>
            <button type='submit' <?php if(!isset($match[7]) || isset($match[8])){echo'disabled';}?> name='valider9'class="form-contro submit"> jouer match</button></br></br>

            </form>
            <?php
            if(isset($_POST['valider9']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,8,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gA[0],$gA[3],'classement_groupea');
                header('location:phase_groupe.php#match_9');
                
            }

            ?>
            <!-- ------------------------------------------------------------------------------------------------------------------------------ -->
            <form id='match_10' method='POST'>

            <label><img src='<?php echo $flagA[1]?>'> <?php echo $gA[1] ;       ?>
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[9]]?>' class="form-contr"> VS
            <input type="number"  disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[9]]?>' class="form-contr">
            <label> <?php echo  $gA[2];?><img src='<?php echo $flagA[2]?>'></br></br>
            <button type='submit' <?php if(!isset($match[8]) || isset($match[9])){echo'disabled';}?> name='valider10'class="form-contro submit"> jouer match</button></br></br>

            </form>

            <?php
            if(isset($_POST['valider10']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,9,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gA[1],$gA[2],'classement_groupea');
                header('location:phase_groupe.php#match_10');
                
            }

            ?>
            <!-- ------------------------------------------------------------------------------------------------------------------------------>

            <h2> GROUPE B </h2>
            <form id='match_11' method='POST'>
            <label><img src='<?php echo $flagB[0]?>'> <?php echo $gB[0] ;       ?> 
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[10]]?>' class="form-contr"> VS
            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[10]]?>' class="form-contr">
            <label> <?php echo     $gB[3] ;?><img src='<?php echo $flagB[3]?>'></br></br>
            <button type='submit' <?php if(!isset($match[9]) || isset($match[10])){echo'disabled';}?> name='valider11'class="form-contro submit"> jouer match</button></br></br>

            </form>

            <?php
            if(isset($_POST['valider11']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,10,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gB[0],$gB[3],'classement_groupeb');
                header('location:phase_groupe.php#match_11');
                
            }

            ?>
            <!-- ------------------------------------------------------------------------------------------------------------------------------>


            <form id='match_12' method='POST'>

            <label><img src='<?php echo $flagB[1]?>'> <?php echo $gB[1] ;       ?> 
            <input type="number" disabled name='score1' min='0' max='12' value='<?php echo $score1[$match[11]]?>' class="form-contr"> VS
            <input type="number" disabled name='score2' min='0' max='12' value='<?php echo $score2[$match[11]]?>' class="form-contr"> 
            <label> <?php echo   $gB[2] ;?><img src='<?php echo $flagB[2]?>'></br></br>
            <button type='submit' <?php if(!isset($match[10]) || isset($match[11])){echo'disabled';}?> name='valider12' class="form-contro submit"> jouer match</button></br></bres

            </form>

            <?php
            if(isset($_POST['valider12']))
            {
                if(isset($_POST['scrore1']) && isset($_POST['scrore1']))
                    {
                    $scr1=$_POST['score1'];
                    $scr2=$_POST['score2'];
                    
                    }
                else
                    {
                        $scr1=rand(0,5);
                        $scr2=rand(0,5);
                        
                    }

            $insert = "INSERT INTO match_joue VALUES (null,11,$scr1,$scr2,'groupe')";
                            $conn->exec($insert);
                jouerMatch($scr1,$scr2,$gB[1],$gB[2],'classement_groupeb');
                header('location:phase_groupe.php#match_12');
                
            }

            ?>
            

                        </div>
                    </article>
            <?php
                if(isset($match[11]))
                    {?>
                        <center><button type='submit' name='next'><a href="phase_eliminatoire.php" >SUIVANT</a></button></center><br/><br/>
                        <!-- <center><a href="phase_eliminatoire.php" ><button type='submit' name='next'>SUIVANT</button></center></a><br/> -->
                
                        
                    <?php } ?>
                            
                    <!-- ------------------------------------------------------------------------------------------------------------------------------>

            </section>
    </body>
</html>
