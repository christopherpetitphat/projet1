<?php

// connection a la base de donnée

try{ $conn = new 
    PDO('mysql:host=localhost; dbname=competition; charset=utf8', 'root', ''); 

} catch (Exception $e){ die('Erreur : ' . $e->getMessage()); } 

?>