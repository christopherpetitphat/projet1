<!DOCTYPE html>
<head>
    <title>COUPE INFO 3</title>
    <meta charset="utf-8">
    <link href="style.css" rel="Stylesheet"  /> 
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
</head>
<body>
   <nav>
       <input type="checkbox" id="check">
       <label for="check" class="checkbtn">
       </label>
       <label class="logo">CHAMPIONNAT</label>
       <ul>
        <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
        <li><p> <i class="fa fa-sort"><a href="classement.php">Classement</a></i></p></li>
      </ul>
   </nav>
   <body>
    <!-- <h1>
        <span>c</span>
        <span>h</span>
        <span>a</span>
        <span>m</span>
        <span>p</span>
        <span>i</span>
        <span>o</span>
        <span>n</span>
        <span>n</span>
        <span>a</span>
        <span>t</span>
    </h1> -->
   <section>    
           <br><br><br>
            <?php
                    include 'connexion_BD.php';
                    session_start();
                    $equipe1='Brésil';
                    $equipe2="France";
                    $equipe3="Espagne";
                    $equipe4="Portugal";
                    $equipe5="Argentine";
                    $equipe6="Italie";
                    $equipe7="Allemagne";
                    $equipe8="Haiti";
           ?>
        <article>
                <div class="mes_article">
                    <div class="searchs">
            
                            <table class="tableau-style"> 
                                        <th>
                                            Lot 1
                                        </th>
                                        <th>
                                            Lot 2
                                        </th>
                                        <th>
                                            Lot 3
                                        </th>
                                        <th>
                                            Lot 4
                                        </th>
                                    <tr>
                                        <td ><img src="image/Brésil.png" > <?php echo $equipe1;?></td>
                                        <td ><img src="image/France.png" ><?php echo $equipe2;?> </td>
                                        <td ><img src="image/Espagne.png"><?php echo $equipe3;?> </td>
                                        <td ><img src="image/Portugal.png"><?php echo $equipe4;?> </td>
                                    </tr>
                                    <tr>
                                        <td ><img src="image/Argentine.png"><?php echo $equipe5;?> </td>
                                        <td ><img src="image/Italie.png" ><?php echo $equipe6;?></td>
                                        <td ><img src="image/Allemagne.png" ><?php echo $equipe7;?> </td>
                                        <td ><img src="image/Haiti.png"><?php echo $equipe8;?></td>
                                    </tr>

                            </table>
                        </div>                  
                </div>           
            </div>
        </article>
     </br></br></br></br></br>
            <form method="POST">
            <center><button type="input" name="tirage" > <a href='traitement.php' type="button">Effectuer tirage </a></button></center><br/><br/>
            <!-- <center><a href="traitement.php" ><button type='submit' name='tirage'>Effectuer tirage</button></center></a><br/><br/>       -->
        </form>

        <?php                
             $_SESSION ['lot1']=array($equipe1,$equipe5);
             $_SESSION ['lot2']=array($equipe2,$equipe6);
             $_SESSION ['lot3']=array($equipe3,$equipe7);
             $_SESSION ['lot4']=array($equipe4,$equipe8)      
        ?>


<!-- Affichage des résultats du tirage -->
<article>
                <div class="mes_article">
                    <div class="searchs">
                
                        <table id="tableau" class="tableau-style"> 
                            <tr>
                                <th>GROUPE A</th>
                            </tr>
                            <?php
                                $req = "SELECT * from groupea";
                                $result = $conn->query($req);
                                $row = $result->fetchAll();
                                for($i = 0; $i < count($row); $i++){
                            ?>
                            <tr>
                                <td><img src='<?php echo $row[$i]['drapeau']?>'><?php echo $row[$i]['nom_equipe'] ?></td>
                            </tr>

                             <?php } ?>
                        </table>
                        </br> </br> </br> </br>
                        <table class="tableau-style"> 
                                <tr>
                                    <th>GROUPE B</th>
                                </tr>
                                <?php
                                    $req = "SELECT * from groupeb";
                                    $result = $conn->query($req);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                ?>
                                <tr>
                                    <td><img src='<?php echo $row[$i]['drapeau']?>'><?php echo $row[$i]['nom_equipe'] ?></td>
                                </tr>

                                <?php } ?>


                        </table>   
                                   
                        <!-- <button type='submit' name='next' class="form-contro submit"> <a href='phase_groupe.php'>SUIVANT </a> </button>                                -->
                    </br> 
                    </div>           
                </div>
            </article>
            <center><a href="phase_groupe.php" ><button type='submit' name='next'>SUIVANT</button></center></a><br/><br/>
</section>

    </body>
</html>