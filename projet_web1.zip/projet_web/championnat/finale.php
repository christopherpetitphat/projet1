<!DOCTYPE html>
        <head>
            <title>COUPE INFO 3</title>
            <meta charset="utf-8">
            <link href="stylef.css" rel="Stylesheet"  /> 
            <script src="https://kit.fontawesome.com/a076d05399.js"></script>
            <link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.1-web/css/all.min.css" />
        </head>
    <body>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                </label>
                <label class="logo">CHAMPIONNAT</label>
                <ul>
                    <li><p> <i class="fa fa-home"><a href="index.php">ACCEUIL</a></i></p></li>
                </ul>
            </nav>
        <section> 
     
                <?php
                  include 'connexion_BD.php'

                ?>
      <br><br>
        <article>
            <div class="mes_articles">                     
                        <br/><h1 class="ecrit"> TROISIEME PLACE </h1>

                            <?php

                                    $troisieme=[];
                                    $req = "SELECT * from phase_finale where place='troisieme'";
                                    $result = $conn->query($req);
                                    $row = $result->fetchAll();
                                    for($i = 0; $i < count($row); $i++){
                                        $troisieme[] = $row[$i]['equipe'];
                                        
                                    }

                            ?>

                <p>
                <img src='image/<?php echo $troisieme[0]?>.png'>
                <?php echo $troisieme[0]?>
                </p>

                    <br/><h1  class="ecrit"> DEUXIEME PLACE </h1>
                        <?php

                            $deuxieme=[];
                            $req1 = "SELECT * from phase_finale where place='deuxieme'";
                            $result = $conn->query($req1);
                            $row = $result->fetchAll();
                            for($i = 0; $i < count($row); $i++){
                                $deuxieme[] = $row[$i]['equipe'];
                                
                            }

                        ?>

                        <p>
                        <img src='image/<?php echo $deuxieme[0]?>.png'>
                        <?php echo $deuxieme[0]?>
                        </p>
            </div>
        </article>
        <article>
            <div class="mes_articles">
                <br/><h1  class="ecrit"> CHAMPION </h1>

                        <?php

                            $champion=[];
                            $req2 = "SELECT * from phase_finale where place='premier'";
                            $result = $conn->query($req2);
                            $row = $result->fetchAll();
                            for($i = 0; $i < count($row); $i++){
                                $champion[] = $row[$i]['equipe'];
                                
                            }
                        ?>

                            <p>
                                <img src='image/<?php echo $champion[0]?>.png'>
                                <?php echo $champion[0]?>
                            </p>
                
                        
            </div>
        </article>
<!-- ------------------------------------------------------------------------------------------------------------------------------ -->


     </body>
     <br><br><br>
     <footer>
        <div id="copy"> CHAMPIONNAT </div>
     </footer>
<html>
